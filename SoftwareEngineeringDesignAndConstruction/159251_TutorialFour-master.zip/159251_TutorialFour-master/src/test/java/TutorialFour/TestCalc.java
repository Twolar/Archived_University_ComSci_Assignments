package TutorialFour;



import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class TestCalc
{
   @Test
   public void testAdd()
   {
       assertEquals(10, new Calc().add(7,3));
   }

   @Test
   public void testSubtract()
   {
       assertEquals(10, new Calc().subtract(20,10));
   }
}