A README file 

but, don't read this file!!!!! 

